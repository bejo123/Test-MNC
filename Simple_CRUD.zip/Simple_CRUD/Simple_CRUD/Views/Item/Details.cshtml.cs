using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Simple_CRUD.Views.Item
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
