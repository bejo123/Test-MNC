using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Simple_CRUD.Views.Item
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
