using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Simple_CRUD.Views.Item
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
