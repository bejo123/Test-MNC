using Microsoft.AspNetCore.Mvc;

namespace SimpleWebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SimpleController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            return Ok("Ini adalah contoh API GET sederhana.");
        }

        [HttpPost]
        public IActionResult Post(DataModel data)
        {
            if (data == null)
            {
                return BadRequest("Data tidak boleh kosong.");
            }

            if (string.IsNullOrEmpty(data.Name))
            {
                return BadRequest("Nama tidak boleh kosong.");
            }

            if (data.Age <= 0)
            {
                return BadRequest("Umur harus lebih besar dari 0.");
            }

            // Proses data lebih lanjut di sini
            return Ok($"Data diterima. Nama: {data.Name}, Umur: {data.Age}");
        }
    }

    public class DataModel
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
