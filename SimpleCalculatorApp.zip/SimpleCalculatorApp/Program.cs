using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

class Program
{
    static void Main(string[] args)
    {
        var host = new WebHostBuilder()
            .UseKestrel()
            .Configure(app =>
            {
                app.UseStaticFiles();

                app.Run(context =>
                {
                    if (context.Request.Method == "POST")
                    {
                        var num1String = context.Request.Form["num1"];
                        var num2String = context.Request.Form["num2"];
                        var op = context.Request.Form["operation"];

                        if (double.TryParse(num1String, out double num1) && double.TryParse(num2String, out double num2))
                        {
                            double result = 0;

                            switch (op)
                            {
                                case "tambah":
                                    result = num1 + num2;
                                    break;
                                case "kurang":
                                    result = num1 - num2;
                                    break;
                                case "kali":
                                    result = num1 * num2;
                                    break;
                                case "bagi":
                                    if (num2 == 0)
                                    {
                                        return context.Response.WriteAsync("Tidak dapat melakukan pembagian dengan nol!");
                                    }
                                    result = num1 / num2;
                                    break;
                                default:
                                    return context.Response.WriteAsync("Operasi tidak valid!");
                            }

                            return context.Response.WriteAsync($@"
                                <html>
                                <head>
                                    <link rel='stylesheet' type='text/css' href='/styles.css'>
                                </head>
                                <body>
                                    <div class='calculator'>
                                        <h1>Kalkulator Sederhana</h1>
                                        <p>Hasil: {result}</p>
                                        <br>
                                        <a href='/'>Kembali ke Kalkulator</a>
                                    </div>
                                </body>
                                </html>
                            ");
                        }
                        else
                        {
                            return context.Response.WriteAsync("Input tidak valid. Mohon masukkan angka yang valid.");
                        }
                    }

                    context.Response.ContentType = "text/html";
                    return context.Response.WriteAsync(@"
                        <html>
                        <head>
                            <link rel='stylesheet' type='text/css' href='/styles.css'>
                        </head>
                        <body>
                            <div class='calculator'>
                                <h1>Kalkulator Sederhana</h1>
                                <form method='post'>
                                    <input type='text' name='num1' placeholder='Masukkan angka pertama'><br><br>
                                    <input type='text' name='num2' placeholder='Masukkan angka kedua'><br><br>
                                    <select name='operation'>
                                        <option value='tambah'>+</option>
                                        <option value='kurang'>-</option>
                                        <option value='kali'>x</option>
                                        <option value='bagi'>÷</option>
                                    </select><br><br>
                                    <button type='submit'>Hitung</button>
                                </form>
                            </div>
                        </body>
                        </html>
                    ");
                });
            })
            .Build();

        host.Run();
    }
}
